package com.infinite.jsf.recipient.model;

public enum Status {
	ACTIVE,INACTIVE,BLOCKED

}
