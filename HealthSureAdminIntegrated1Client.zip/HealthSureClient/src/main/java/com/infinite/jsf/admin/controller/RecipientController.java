package com.infinite.jsf.admin.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

import com.infinite.jsf.admin.dao.RecipientDao;
import com.infinite.jsf.admin.daoImpl.RecipientDaoImpl;
import com.infinite.jsf.recipient.model.Recipient;

public class RecipientController {
	

	
    private RecipientDao recipientDao;
    private Recipient recipient;

    // Search fields
    private String searchHid;
    private String searchFirstName;
    private String searchMobile;
    private String searchCreatedAt;

    //----dropdown search fields----
    private String searchType;
    private String searchValue;

    private List<Recipient> recipientList;

    // ----- Fields for sorting -----
    private String sortColumn = "";
    private boolean sortAscending = true;

    
 // Pagination and search helpers
    private List<Recipient> resultList;
//    private List<Recipient> paginatedSearchList;
    private int totalPages = 0;

    

    // ----- Fields for Pagination  -----
    
    private int currentPage = 0;
    private int pageSize = 5;

    // ----- Fields for search field contains mode  -----
    private String nameSearchMode = ""; // default mode


    
    
//  -----------HYPERLINK 1---------
    public String prepareUpdate() {
        // Read parameter sent from <f:param>
        String hId = FacesContext.getCurrentInstance()
                      .getExternalContext()
                      .getRequestParameterMap()
                      .get("hid");

        System.out.println("prepareUpdate() called for hId: " + hId);

        // Fetch from DAO using hId
        this.recipient = recipientDao.getRecipientByhId(hId);
        this.recipientLoaded = true; // Mark as loaded manually

        return "UpdateRecipient1";  // Navigate to update page
    }
    
//  ========================Hyperlink 3===========================


	private boolean recipientLoaded = false;

    public Recipient getRecipient() {
        if (!recipientLoaded) {
            loadRecipientForUpdate();
            recipientLoaded = true;
        }
        return this.recipient;
    }



	public void loadRecipientForUpdate() {
        try {
            FacesContext context = FacesContext.getCurrentInstance();

            if (context == null) {
                System.out.println("⚠️ FacesContext is null — skipping.");
                return;
            }

            Map<String, String> params = context.getExternalContext().getRequestParameterMap();

            if (params == null) {
                System.out.println("Parameter map is null.");
                return;
            }

            String hidParam = params.get("hid");

            if (hidParam != null && !hidParam.trim().isEmpty()) {
                this.recipient = recipientDao.getRecipientByhId(hidParam);

                if (this.recipient != null) {
                    this.searchHid = recipient.gethId();
                    this.searchFirstName = recipient.getFirstName();
                    this.searchMobile = recipient.getMobile();
                    System.out.println("Recipient loaded via hid param: " + hidParam);
                } else {
                    System.out.println("No recipient found for hid: " + hidParam);
                }
            } else {
                System.out.println("No hid param provided.");
            }

        } catch (Exception e) {
            System.out.println("Exception in loadRecipientForUpdate: " + e.getMessage());
            e.printStackTrace();
        }
    }


    


  
//--- SHOW PAGE NAVIGATION METHOD ---
  public String goToShowPage() {
      this.recipientList = null;   // force a fresh fetch
      this.sortColumn    = "";     
      // optional: reset sort
      this.currentPage   = 0;      // optional: reset pagination
      return "ShowRecipient1";     // target JSF page
  }
    
    // ----- Getters & Setters -----

    public RecipientDao getRecipientDao() {
        return recipientDao;
    }

    
    public void setRecipientDao(RecipientDao recipientDao) {
        this.recipientDao = recipientDao;
    }

//    public Recipient getRecipient() {
//        return recipient;
//    }

    public void setRecipient(Recipient recipient) {
        this.recipient = recipient;
    }
    
//===============HYPERLINK 2==================
    private Recipient selectedRecipient;  // TEMPORARY holder

    // Getter and Setter for selectedRecipient
    public Recipient getSelectedRecipient() {
     return selectedRecipient;
    }
    
    public void setSelectedRecipient(Recipient selectedRecipient) {
     this.selectedRecipient = selectedRecipient;
    }
    




    public String getSearchHid() {
        return searchHid;
    }

    public void setSearchHid(String searchHid) {
        this.searchHid = searchHid;
    }

    public String getSearchFirstName() {
        return searchFirstName;
    }

    public void setSearchFirstName(String searchFirstName) {
        this.searchFirstName = searchFirstName;
    }

    public String getSearchMobile() {
        return searchMobile;
    }

    public void setSearchMobile(String searchMobile) {
        this.searchMobile = searchMobile;
    }

    public String getSearchCreatedAt() {
        return searchCreatedAt;
    }

    public void setSearchCreatedAt(String searchCreatedAt) {
        this.searchCreatedAt = searchCreatedAt;
    }

    public List<Recipient> getRecipientList() {
        return recipientList;
    }
    
    //-----For searchType and searchValue for search ----    
    public String getSearchType() {
    	return searchType;
    }
    
    public void setSearchType(String searchType) {
    	this.searchType= searchType;
    }
    
    public String getSearchValue() {
    	return searchValue;
    }
    
    public void setSearchValue(String searchValue) {
    	this.searchValue = searchValue;
    }

    public void setRecipientList(List<Recipient> recipientList) {
        this.recipientList = recipientList;
    }
    
    
    //-----Method For searchMode ----    
    public String getNameSearchMode() {
        return nameSearchMode;
    }

    public void setNameSearchMode(String nameSearchMode) {
        this.nameSearchMode = nameSearchMode;
    }

    
    //----For Sort----     
    public String getSortColumn() {
        return sortColumn;
    }

    public boolean isSortAscending() {
        return sortAscending;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getPageSize() {
        return pageSize;
    }
    
    /** List of page indexes (0‑based) that the JSP will iterate over. */
    public List<Integer> getPageIndexes() {
        int pages = getTotalPages();
        List<Integer> list = new ArrayList<Integer>(pages);
        for (int i = 0; i < pages; i++) list.add(i);
        return list;
    }

    /** Action method called by each page number link. */
    public String goToPage(int pageIndex) {
//        this.currentPage = pageIndex;
        return null;                  // stay on same view
    }
    
    
 // --- (OPTIONAL) helper for the CSS class -----------
    public String styleClassForPage(int pageIndex) {
        return (currentPage == pageIndex) ? "active-page" : "page-link";
    }
    
    // TO Show all sorted and paginated items
    public List<Recipient> getShowRecipient() {
    	isSearchContext = false;
        if (recipientDao == null) {
            System.out.println("recipientDao not injected!");
            return Collections.emptyList();
        }

        if (recipientList == null ) {
            recipientList = recipientDao.showAllRecipients();
            resetPagination();  // go to page 0
        }

        
//        sortResults(); // Always sort based on current sortColumn + sortAscending
        performSorting();
        return getPaginatedList();
    }
    public String getPageLabel(int pageIndex) {
        return String.valueOf(pageIndex + 1);
    }
 

    // -----------SORTING---------------- 
    
    
    private boolean isSearchContext = false;

 // Add these helper methods at the class level
 private int compareStrings(String s1, String s2) {
     if (s1 == null && s2 == null) return 0;
     if (s1 == null) return -1;
     if (s2 == null) return 1;
     return s1.compareToIgnoreCase(s2);
 }

 private int compareDates(Date d1, Date d2) {
     if (d1 == null && d2 == null) return 0;
     if (d1 == null) return -1;
     if (d2 == null) return 1;
     return d1.compareTo(d2);
 }
    
    
    //sorting methods separated by arrows icon
      public String sortByAsc(String column) {
          this.sortColumn = column;
          this.sortAscending = true;
          performSorting();
          resetPagination(); 
          return null;
          
      }

      public String sortByDesc(String column) {
          this.sortColumn = column;
          this.sortAscending = false;
          performSorting();
          resetPagination(); // Optional
          return null;
      }
      

//      1
//      private void performSorting() {
//    	    if (isSearchContext) {
//    	        if (searchResultList != null) {
//    	            sortSearchResults();
//    	        }
//    	    } else {
//    	        if (recipientList != null) {
//    	            sortResults();
//    	        }
//    	    }
//    	}

      private void performSorting() {
    	  if (searchResultList != null) {
    	        sortSearchResults();
    	    }
      }
      
      
      
    
    
    
    public String sortBy(String column) {
        if (column.equals(this.sortColumn)) {
            this.sortAscending = !this.sortAscending;
        } else {
            this.sortColumn = column;
            this.sortAscending = true;
        }
//        2
//        performSorting();
        sortResults();
        resetPagination();
        currentPage=0;
        return null;
    }


 //===============sorting method for search results===================
    private void sortSearchResults() {
        if (searchResultList == null || searchResultList.isEmpty()) {
            return;
        }

        Collections.sort(searchResultList, new Comparator<Recipient>() {
            public int compare(Recipient r1, Recipient r2) {
                // Reuse the same comparison logic from sortResults()
                if (r1 == null && r2 == null) return 0;
                if (r1 == null) return -1;
                if (r2 == null) return 1;

                int result = 0;
                try {
                    switch (sortColumn) {
                        case "hId":
                            result = compareStrings(r1.gethId(), r2.gethId());
                            break;
                        case "firstName":
                            result = compareStrings(r1.getFirstName(), r2.getFirstName());
                            break;
                        case "lastName":
                            result = compareStrings(r1.getLastName(), r2.getLastName());
                            break;
                        case "mobile":
                            result = compareStrings(r1.getMobile(), r2.getMobile());
                            break;
                        case "email":
                            result = compareStrings(r1.getEmail(), r2.getEmail());
                            break;
                        case "address":
                            result = compareStrings(r1.getAddress(), r2.getAddress());
                            break;
                        case "createdAt":
                            result = compareDates(r1.getCreatedAt(), r2.getCreatedAt());
                            break;
                        case "lastModifiedAt":
                            result = compareDates(r1.getLastModifiedAt(), r2.getLastModifiedAt());
                            break;
                        default:
                            result = 0;
                    }
                } catch (NullPointerException e) {
                    result = 0;
                }
                return sortAscending ? result : -result;
            }
        });
    }

//=====================sorting method for show page=========================
    private void sortResults() {
        if (recipientList == null || recipientList.isEmpty()) {
            return;
        }

        Collections.sort(recipientList, new Comparator<Recipient>() {
            public int compare(Recipient r1, Recipient r2) {
                // Handle null objects
                if (r1 == null && r2 == null) return 0;
                if (r1 == null) return -1;
                if (r2 == null) return 1;

                int result = 0;
                try {
                    switch (sortColumn) {
                        case "hId":
                            result = compareStrings(r1.gethId(), r2.gethId());
                            break;
                        case "firstName":
                            result = compareStrings(r1.getFirstName(), r2.getFirstName());
                            break;
                        case "lastName":
                            result = compareStrings(r1.getLastName(), r2.getLastName());
                            break;
                        case "mobile":
                            result = compareStrings(r1.getMobile(), r2.getMobile());
                            break;
                        case "email":
                            result = compareStrings(r1.getEmail(), r2.getEmail());
                            break;
                        case "address":
                            result = compareStrings(r1.getAddress(), r2.getAddress());
                            break;
                        case "createdAt":
                            result = compareDates(r1.getCreatedAt(), r2.getCreatedAt());
                            break;
                        case "lastModifiedAt":
                            result = compareDates(r1.getLastModifiedAt(), r2.getLastModifiedAt());
                            break;
                        default:
                            result = 0;
                    }
                    
                } catch (NullPointerException e) {
                    result = 0; // Fallback if any field is null
                }
                return sortAscending ? result : -result;
            }

            private int compareStrings(String s1, String s2) {
                if (s1 == null && s2 == null) return 0;
                if (s1 == null) return -1;
                if (s2 == null) return 1;
                return s1.compareToIgnoreCase(s2);
            }

            private int compareDates(Date d1, Date d2) {
                if (d1 == null && d2 == null) return 0;
                if (d1 == null) return -1;
                if (d2 == null) return 1;
                return d1.compareTo(d2);
            }
        });
    }
  
 // Add these new methods
    public boolean isColumnSorted(String column) {
        return column.equals(this.sortColumn);
    }

    public boolean isAscending() {
        return this.sortAscending;
    }

    public boolean isDescending() {
        return this.sortColumn != null && !this.sortAscending;
    }
    
    
    
    
    
    
    
    // -----------Pagination Methods---------------
    
    
    
//    current page =1;
//    reset pagination();
    
    
    
    
    public List<Recipient> getPaginatedList() {
        if (recipientList == null || recipientList.isEmpty()) {
            return Collections.emptyList();
        }

        int start = currentPage * pageSize;
        int end = Math.min(start + pageSize, recipientList.size());

        // Additional null check
        if (start >= recipientList.size() || start < 0) {
            currentPage = 0;
            start = 0;
            end = Math.min(pageSize, recipientList.size());
        }
        
        
        
        return recipientList.subList(start, end);
    }

    public int getTotalPages() {
        return recipientList == null ? 1
             : (int) Math.ceil((double) recipientList.size() / pageSize);
    }

    public boolean isNextButtonDisabled() {
        return recipientList == null || (currentPage >= getTotalPages() - 1);
    }
    public boolean isPreviousButtonDisabled() { return currentPage == 0; }

    public String nextPage()      { if (!isNextButtonDisabled())     currentPage++; return null; }
    public String previousPage()  { if (!isPreviousButtonDisabled()) currentPage--; return null; }

    private void resetPagination() { currentPage = 0; }
    
    public String getPageNumberDisplay() {
        int total = getTotalPages();
        if (total == 0) total = 1;
        return "Page " + (currentPage + 1) + " of " + total;
    }




    public List<Integer> getPageNumbers() {
        int total;
        if (resultList != null && !resultList.isEmpty()) {
            total = getSearchTotalPages();
        } else {
            total = getTotalPages();
        }
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= total; i++) {
            numbers.add(i);
        }
        return numbers;
    }


    
    
    public String goToPage() {
        FacesContext context = FacesContext.getCurrentInstance();
        String page = context.getExternalContext().getRequestParameterMap().get("page");
        
        try {
            int requestedPage = Integer.parseInt(page) - 1; // Convert to 0-based
            int totalPages = (resultList != null && !resultList.isEmpty()) 
                           ? getSearchTotalPages() 
                           : getTotalPages();
            
            // Validate page range
            currentPage = Math.max(0, Math.min(requestedPage, totalPages - 1));
        } catch (NumberFormatException e) {
            currentPage = 0;
        }
        return null;
    }

    public void calculateTotalPages() {
        if (resultList != null && !resultList.isEmpty()) {
            totalPages = (int) Math.ceil((double) resultList.size() / pageSize);
        } else {
            totalPages = 1;
        }
    }
    
    
    
    
    
   
    public List<Recipient> getPaginatedSearchResults() {
        if (resultList == null || resultList.isEmpty()) {
            return Collections.emptyList();
        }

        // Ensure currentPage is within valid bounds
        int maxPage = Math.max(0, getSearchTotalPages() - 1);
        currentPage = Math.min(currentPage, maxPage);
        
        int start = currentPage * pageSize;
        int end = Math.min(start + pageSize, resultList.size());

        return resultList.subList(start, end);
    }

    
    
    
    public int getSearchTotalPages() {
        return resultList == null ? 1 
             : (int) Math.ceil((double) resultList.size() / pageSize);
    }

    public String goToSearchPage() {
        FacesContext context = FacesContext.getCurrentInstance();
        Map<String, String> params = context.getExternalContext().getRequestParameterMap();
        String pageParam = params.get("page");
        
        try {
            currentPage = Integer.parseInt(pageParam);
        } catch (NumberFormatException e) {
            currentPage = 0; // Default to first page if conversion fails
        }
        return null;
    }


    
    
    public List<Integer> getSearchPageIndexes() {
    	int pages = getSearchTotalPages();
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < searchTotalPages; i++) {
            list.add(i); // Returns List of Integers
        }
        return list;
    }
    

    
    public void calculateSearchTotalPages() {
        if (resultList != null && !resultList.isEmpty()) {
            searchTotalPages = (int) Math.ceil((double) resultList.size() / pageSize);
        } else {
            searchTotalPages = 1;
        }
    }


//===========methods for disabling the paginations buttons=============
    public boolean isFirstPage() {
        return currentPage == 0;
    }

    public boolean isLastPage() {
        return currentPage >= getSearchTotalPages() - 1;
    }
    
    
    public boolean isOnlyOnePage() {
        return searchPageCount <= 1;
    }
    
    
    
    
    private boolean firstSearchPageDisabled;
    private boolean lastSearchPageDisabled;

    
    public boolean lastSearchPageDisabled() {
        return isLastSearchPageDisabled();
    }
    
    
    
   
    // Add setters if needed
    public void setFirstSearchPageDisabled(boolean firstSearchPageDisabled) {
        this.firstSearchPageDisabled = firstSearchPageDisabled;
    }

    public void setLastSearchPageDisabled(boolean lastSearchPageDisabled) {
        this.lastSearchPageDisabled = lastSearchPageDisabled;
    }
    public boolean shouldDisablePrevious() {
        return firstSearchPageDisabled || isFirstPage() || isOnlyOnePage();
    }

    public boolean shouldDisableNext() {
        return lastSearchPageDisabled || isLastPage() || isOnlyOnePage();
    }
    
    
    public boolean isPreviousDisabled() {
        return isFirstSearchPageDisabled() || isFirstPage() || isOnlyOnePage();
    }

    public boolean isNextDisabled() {
        return currentPage >= getSearchTotalPages() - 1 || 
               resultList == null || 
               resultList.isEmpty();
    }

    
    
    
    
    
    
//    ===========================================
    
 // ===== SEARCH PAGINATION FIELDS =====
    private int searchCurrentPageIndex = 0;
    private final int searchResultsPerPage = 5;
    private int searchPageCount = 1;
    private List<Recipient> searchResultList = new ArrayList<>();
//    private boolean searchPerformed = false;


    // ===== PROPERTY ACCESSORS =====
    public int getSearchCurrentPageIndex() {
        return searchCurrentPageIndex;
    }

    public void setSearchCurrentPageIndex(int searchCurrentPageIndex) {
        this.searchCurrentPageIndex = searchCurrentPageIndex;
    }

    public int getSearchResultsPerPage() {
        return searchResultsPerPage;
    }

    public int getSearchPageCount() {
        return searchPageCount;
    }

    public List<Recipient> getSearchResultList() {
        return searchResultList;
    }

    
    
    
    // ===== SEARCH PAGINATION METHODS =====
    public List<Recipient> getCurrentSearchResultsPage() {
        if (searchResultList == null || searchResultList.isEmpty()) {
        	sortResults();
            return Collections.emptyList();
        }
        
        searchCurrentPageIndex = Math.min(searchCurrentPageIndex, computeSearchPageCount() - 1);
        searchCurrentPageIndex = Math.max(searchCurrentPageIndex, 0);
        
        int start = searchCurrentPageIndex * searchResultsPerPage;
        int end = Math.min(start + searchResultsPerPage, searchResultList.size());
        
        return searchResultList.subList(start, end);
    }

    

    
    
    
    
    public String navigateToNextSearchPage() {
        if (searchCurrentPageIndex < computeSearchPageCount() - 1) {
            searchCurrentPageIndex++;
        }
        return null;
    }

    public String navigateToPreviousSearchPage() {
        if (searchCurrentPageIndex > 0) {
            searchCurrentPageIndex--;
        }
        return null;
    }
    
    private void updatePageDisabledFlags() {
        firstSearchPageDisabled = (searchCurrentPageIndex == 0);
        lastSearchPageDisabled = (searchCurrentPageIndex >= searchPageCount - 1);
    }
    
    
    
    
    

    public String jumpToSearchPage() {
    	isSearchContext= true;
        FacesContext context = FacesContext.getCurrentInstance();
        String page = context.getExternalContext().getRequestParameterMap().get("page");
        
        try {
            int requestedPage = Integer.parseInt(page) - 1;
            searchCurrentPageIndex = Math.max(0, Math.min(requestedPage, computeSearchPageCount() - 1));
        } catch (NumberFormatException e) {
            searchCurrentPageIndex = 0;
        }
        return null;
    }

    public boolean isFirstSearchPageDisabled() {
        return searchCurrentPageIndex == 0 || searchResultList == null || searchResultList.isEmpty();
    }

    public boolean isLastSearchPageDisabled() {
        return searchCurrentPageIndex >= computeSearchPageCount() - 1 || 
               searchResultList == null || 
               searchResultList.isEmpty();
    }

    public List<Integer> getSearchResultsPageNumbers() {
        int total = computeSearchPageCount();
        List<Integer> numbers = new ArrayList<>();
        for (int i = 1; i <= total; i++) {
            numbers.add(i);
        }
        return numbers;
    }

    private int computeSearchPageCount() {
        if (searchResultList == null || searchResultList.isEmpty()) {
            return 1;
        }
        return (int) Math.ceil((double) searchResultList.size() / searchResultsPerPage);
    }
    
    
    

    public void resetSearchResultsPagination() {
        searchCurrentPageIndex = 0;
        searchPageCount = computeSearchPageCount();
    }
    
//    ============================================
    
    
   
    
//    ===========new fields for created at or date range=============
    
    private String fromDate;
    private String toDate;

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
    
    private String searchCreatedAtStart;
    private String searchCreatedAtEnd;

    
    
    public String getSearchCreatedAtStart() {
		return searchCreatedAtStart;
	}

	public void setSearchCreatedAtStart(String searchCreatedAtStart) {
		this.searchCreatedAtStart = searchCreatedAtStart;
	}
	
	public String getSearchCreatedAtEnd() {
		return searchCreatedAtEnd;
	}
	
	public void setSearchCreatedAtEnd(String searchCreatedAtEnd) {
		this.searchCreatedAtEnd = searchCreatedAtEnd;
	}

	
	public void searchByCreatedAtRange() {
	    FacesContext context = FacesContext.getCurrentInstance();

	    if (fromDate != null && toDate != null && !fromDate.isEmpty() && !toDate.isEmpty()) {
	        recipientList = recipientDao.searchByCreatedAtRange(fromDate, toDate);
	        sortResults();
	        resetPagination();
	    } else {
	        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	                "Please provide both From and To dates.", null));
	        searchPerformed = false;
	    }
	}

	



	
	
	private String searchMode = "exact";  // default value

	public String search() {
		  // Reset search-specific pagination and results
	    resetSearchResultsPagination();
	    searchResultList = new ArrayList<>();
	    searchPerformed = true;

	    isSearchContext = true;
	    System.out.println("=== STARTING SEARCH ===");
	    System.out.println("Search type: " + searchType);
	    System.out.println("Search value: " + searchValue);
	    System.out.println("Name search mode: " + nameSearchMode);  
	    
	    FacesContext context = FacesContext.getCurrentInstance();
	    
	    
	 // If "Show All" is selected, it'll bypass other validations
	    if ("showAll".equals(searchType)) {
	        searchResultList = recipientDao.showAllRecipients();
	        if (searchResultList.isEmpty()) {
	            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, 
	                "No recipients found in the system.", null));
	        }
	        return null;
	    }

	    if (searchType == null || searchType.trim().isEmpty()) {
	        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	            "Please select a search type.", null));
	        searchPerformed = false;
	        return null;
	    }

	    if (searchValue == null || searchValue.trim().isEmpty()) {
	        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	            "Please enter a value for search.", null));
	        searchPerformed = false;
	        return null;
	    }
	    
	    


	    
	    if ("firstName".equals(searchType)) {
	        if (nameSearchMode == null || nameSearchMode.trim().isEmpty()) {
	            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	                "Please select a search mode for First Name (Starts With, Contains, or Exact Match).", null));
	            searchPerformed = false;
	            return null;
	        }
	    }
	    
//	    this.searchPerformed = true;

	    try {
	        switch (searchType) {
	            case "hid":
	                searchValue = searchValue.trim().toUpperCase();
	                searchHid = searchValue;

	                if (!searchHid.matches("HID\\d{3}")) {
	                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	                        "Invalid Health ID.HID must be in format HID followed by 3 digits (e.g. HID001)", null));
	                    searchPerformed = false;
	                    return null;
	                }
	                
	                
	                recipient = recipientDao.searchByHid(searchHid);
	                searchResultList = (recipient !=null) ?Arrays.asList(recipient):new ArrayList<>();
//	                searchByHid();
//	                recipientList = null;
	                break;

	                
	                
	                
	                
	                
	            case "firstName":
	                if (!searchValue.matches("[a-zA-Z]+")) {
	                    context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	                        "First name should contain only alphabets.", null));
	                    searchPerformed = false;
	                    return null;
	                }
	                searchFirstName = searchValue;
	                switch(nameSearchMode) {
	                case "startsWith":
	                    searchResultList = recipientDao.searchByFirstNameStartsWith(searchFirstName);
	                    break;
	                case "contains":
	                    searchResultList = recipientDao.searchByFirstNameContains(searchFirstName);
	                    break;
	                case "exact":
	                    searchResultList = recipientDao.searchByFirstNameExact(searchFirstName);
	                    break;
	                default:
	                    searchResultList = new ArrayList<>();
	                    
	                    break;
	            }
	            break;

	                
	                
	                
	                
	            case "mobile":
	                if (!searchValue.matches("^[6-9][0-9]{9}$")) {
	                    context.addMessage(null, new FacesMessage(
	                        FacesMessage.SEVERITY_ERROR,
	                        "Mobile number must be exactly 10 digits, cannot start with 0, and must not contain letters.",
	                        null));
	                    searchPerformed = false;
	                    return null;
	                }
	                searchMobile = searchValue;

	                searchResultList = recipientDao.searchByMobile(searchMobile);

	                break;
	                


	            default:
	                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	                    "Unknown search type.", null));
	                recipientList = new ArrayList<>();
	                searchPerformed = false;
	                return null;
	        }
	        
	         
	        
	        // Ensure list is never null
//	        if (searchResultList == null) {
//	            searchResultList = new ArrayList<>();
//	        }
//	        
	        if (searchResultList.isEmpty()) {
	            FacesContext.getCurrentInstance().addMessage(null, 
	                new FacesMessage(FacesMessage.SEVERITY_INFO, 
	                "No recipients found with the given value.", null));
	        }
	        
	        // Update pagination
	        searchPageCount = computeSearchPageCount();
	        
	        return null;
	        
	
	        
	    }  catch (Exception e) {
	        context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
	                "Search error: " + e.getMessage(), null));
	            searchResultList = new ArrayList<>();
	            return null;
	        }
	}
  
    

    private int searchTotalPages = 1;  // Total pages available
    public boolean isSearchValueDisabled() {
        return "showAll".equals(searchType);
    }
  

    
    
    
    public void searchByHid() {
        System.out.println("=== SEARCH BY HID ===");
        System.out.println("Searching for HID: " + searchHid);
        
        // Get the recipient from DAO
        recipient = recipientDao.searchByHid(searchHid);
        
        // Set the resultList for pagination
        resultList = (recipient != null) ? Arrays.asList(recipient) : new ArrayList<>();
        
        // Calculate pagination info
        calculateTotalPages();
        resetPagination();
        
        System.out.println("Found recipient: " + recipient);
        System.out.println("Result list size: " + resultList.size());
        System.out.println("Total pages: " + searchTotalPages);
    }
    
    
    
    
    
    public String selectRecipientForUpdate(Recipient selectedRecipient) {
        this.recipient = selectedRecipient;
        return "updateRecipient1.jsp"; //actual page name without .xhtml in nav-rule
    }
    
    
    
    
    
    public void searchByFirstName() {
        System.out.println("=== FIRST NAME SEARCH ===");
        System.out.println("First name: " + searchFirstName);
        System.out.println("Search mode: " + nameSearchMode);
        
        // Initialize empty list if null input
        if (searchFirstName == null || searchFirstName.trim().isEmpty()) {
            resultList = new ArrayList<>();
           
            return;
        }

//        // Set default search mode if not specified
//        if (nameSearchMode == null || nameSearchMode.trim().isEmpty()) {
//            nameSearchMode = "contains";
//        }
        

        try {
//            

        	 switch(nameSearchMode) {
             case "startsWith":
                   resultList = recipientDao.searchByFirstNameStartsWith(searchFirstName);
                 break;
             case "contains":
                 resultList = recipientDao.searchByFirstNameContains(searchFirstName);
                 break;
             case "exact":
                 resultList = recipientDao.searchByFirstNameExact(searchFirstName);
                 break;
             default:
                 resultList = new ArrayList<>();
                 break;
         }
            
            
            
            // Ensure resultList is never null
            if (resultList == null) {
                resultList = new ArrayList<>();
            }

//            // Sort and paginate results
//            sortResults();
//            resetPagination();
//            calculateSearchTotalPages();

            // Debug output
            System.out.println("Found " + resultList.size() + " results");
            resultList.forEach(r -> System.out.println(r.getFirstName()));

            // Force update of the view
            FacesContext.getCurrentInstance().renderResponse();
            
        } catch (Exception e) {
            resultList = new ArrayList<>();
//            resetPagination();
//            calculateSearchTotalPages();
            System.out.println("Error in searchByFirstName: " + e.getMessage());
            e.printStackTrace();
            
            // Add error message to context
            FacesContext.getCurrentInstance().addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                    "Search error: " + e.getMessage(), null));
        }
        
        
        resetPagination();
        calculateSearchTotalPages();  
        
        FacesContext context = FacesContext.getCurrentInstance();
        if (!context.isPostback()) {
            context.getPartialViewContext().getRenderIds()
                .add("searchResultsForm:resultsPanel");
            }
    }

    

    public void searchByMobile() {
        // Mobile search should also populate resultList for pagination
        resultList = recipientDao.searchByMobile(searchMobile);

        if (resultList == null) {
            resultList = new ArrayList<>();
        }

        sortResults();
        resetPagination();
        calculateSearchTotalPages(); // for search
    }

    
    
    public void searchByCreatedAt() {
        recipientList = recipientDao.searchByCreatedAt(searchCreatedAt);
        sortResults();
        resetPagination();
    }
    

//-----------result for a single search---------
    public List<Recipient> getSingleRecipientList() {
        if (recipient != null) {
            return Arrays.asList(recipient);
        }
        return Collections.emptyList();
    }
    
    public List<Recipient> getResultList() {
        if (recipientList != null && !recipientList.isEmpty()) {
            return recipientList;
        } else if (recipient != null) {
            return Arrays.asList(recipient);
        }
        return Collections.emptyList();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    



    //--------Update method WITH VALIDATIONS---------    
    private boolean validateRecipient(Recipient r, FacesContext context) {
        boolean isValid = true;

        // -------- Health ID --------
        if (r.gethId() == null || r.gethId().trim().isEmpty()) {
            context.addMessage("hId", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Health ID is required.", null));
            isValid = false;
        } else if (!r.gethId().trim().matches("^HID\\d{3}$")) {
            context.addMessage("hId", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Health ID must be in format HID001.", null));
            isValid = false;
        }

        // -------- First Name --------
        if (r.getFirstName() == null || r.getFirstName().trim().isEmpty()) {
            context.addMessage("firstName", new FacesMessage(FacesMessage.SEVERITY_ERROR, "First Name is required.", null));
            isValid = false;
        } else if (!r.getFirstName().trim().matches("^[A-Z][a-zA-Z]{1,}$")) {
            context.addMessage("firstName", new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "First Name must start with a capital letter and be at least 2 characters long.", null));
                isValid = false;
            }

        // -------- Last Name --------
        if (r.getLastName() == null || r.getLastName().trim().isEmpty()) {
            context.addMessage("lastName", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Last Name is required.", null));
            isValid = false;
        } else if (r.getLastName().trim().length() < 2) {
            context.addMessage("lastName", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Last Name must be at least 2 characters.", null));
            isValid = false;
        }

        // -------- Mobile --------
        if (r.getMobile() == null || r.getMobile().trim().isEmpty()) {
            context.addMessage("mobile", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Mobile number is required.", null));
            isValid = false;
        } else if (!r.getMobile().trim().matches("^[1-9]\\d{9}$")) {
            context.addMessage("mobile", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Mobile number must be 10 digits and cannot start with 0.", null));
            isValid = false;
        }
        
        
        
        
       
        
        
     // -------- Address --------
        if (r.getAddress() == null || r.getAddress().trim().isEmpty()) {
            context.addMessage("address", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Address is required.", null));
            isValid = false;
        } else {
            // Remove leading/trailing spaces before further checks
            String trimmedAddress = r.getAddress().trim();
            
            if (trimmedAddress.length() < 10) {
                context.addMessage("address", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Address must be at least 10 characters long.", null));
                isValid = false;
            } else if (trimmedAddress.length() > 150) {
                context.addMessage("address", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Address cannot exceed 150 characters.", null));
                isValid = false;
            } else if (!trimmedAddress.matches("^[a-zA-Z0-9\\s,\\-\\.]+$")) {
                context.addMessage("address", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Address can contain only letters, numbers, spaces, commas, hyphens, and periods.", null));
                isValid = false;
            }
        }

        


        
     // -------- EMAIL --------
        String email = r.getEmail();
        if (email == null || email.trim().isEmpty()) {
            context.addMessage("email", new FacesMessage(FacesMessage.SEVERITY_ERROR,
                "Email field is required.", null));
            isValid = false;
        } else if (!email.trim().matches("^[a-zA-Z0-9_%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")) {
            context.addMessage("email", new FacesMessage(FacesMessage.SEVERITY_ERROR,
                "Invalid email format. Example: username@example.com. Use only letters, numbers, and '.', '_', '%', '+', '-' before '@'.", null));
            isValid = false;
        }
        return isValid;
    }
    
    //----------- Address -------------
    
    
    
    
    
//----------UPDATE METHOD------------
    public String updateRecipient() {
    	FacesContext context = FacesContext.getCurrentInstance();
        ExternalContext externalContext = context.getExternalContext();
        Flash flash = externalContext.getFlash();
        flash.setKeepMessages(true); // This ensures messages survive redirect   
        
        
        if (!validateRecipient(recipient, context)) {
            return null;
        }

        try {
            boolean updated = recipientDao.updateRecipient(recipient);
            
            if (updated) {
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                    "Recipient details updated successfully", null));
                
                // To Clear the input fields
                recipient = null;
                searchHid = null;
                
                return "Update_Member?faces-redirect=true";
            } else {
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                    "Update failed. Please try again.", null));
            }
        } catch (Exception e) {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                "System error during update: " + e.getMessage(), null));
        }
        
        return null;
    }

    
    
    
    
    
    
    public String navigateToUpdate() {
        return "UpdateRecipient.jsp?faces-redirect=true";
    }

    public String navigateToView() {
        return "ViewRecipient.jsp?faces-redirect=true";
    }

    public String goToUpdatePage() {
        if (recipient == null || recipient.gethId() == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Please search and select a recipient first."));
            return "Search_Member?faces-redirect=true";
        }
        return "UpdateRecipient1?faces-redirect=true";
    }
    
    

    
//    4
    public String resetUpdate() {
        try {
            if (recipient != null && recipient.gethId() != null) {
                // Get fresh copy
                Recipient freshCopy = recipientDao.getRecipientByhId(recipient.gethId());

                // Overwrite local object
                recipient.setFirstName(freshCopy.getFirstName());
                recipient.setLastName(freshCopy.getLastName());
                recipient.setMobile(freshCopy.getMobile());
                recipient.setEmail(freshCopy.getEmail());
                // Add other fields if needed...

                // Store message in flash scope for redirect to work
                FacesContext context = FacesContext.getCurrentInstance();
                context.getExternalContext().getFlash().setKeepMessages(true);
                context.addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Changes discarded successfully", null));
            }
        } catch (Exception e) {
            FacesContext context = FacesContext.getCurrentInstance();
            context.getExternalContext().getFlash().setKeepMessages(true);
            context.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error discarding changes", null));
        }

        // Redirect to same view
        return "UpdateRecipient1?faces-redirect=true&hid=" + recipient.gethId();
    }


    
    public void fetchRecipientBySearchHid() {
        FacesContext context = FacesContext.getCurrentInstance();
        
        // Clear previous messages for searchHid
        Iterator<FacesMessage> messages = context.getMessages("searchHid");
        while (messages.hasNext()) {
            messages.next();
            messages.remove();
        }
        
        // Validate HID
        if (searchHid == null || searchHid.trim().isEmpty()) {
            context.addMessage("searchHid", new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Health ID is required.", null));
            return;
        }
        
        searchHid = searchHid.trim();
        if (!searchHid.matches("^HID\\d{3}$")) {
            context.addMessage("searchHid", new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Health ID must be in format HID001.", null));
            return;
        }

        // If validation passed, proceed with search
        try {
            this.recipient = recipientDao.searchByHid(searchHid);
            
            if (this.recipient != null) {
                context.addMessage(null, 
                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Recipient loaded successfully", ""));
            } else {
                context.addMessage(null, 
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "No recipient found with HID: " + searchHid, ""));
            }
        } catch (Exception e) {
            context.addMessage(null, 
                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error searching for recipient: " + e.getMessage(), ""));
        }
        
        this.searchPerformed = true;
    }
    
    public String goToSearch() {
        FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);
    	return "Search_Member?faces-redirect=true";
    }

    public String goToDashboard() {
    	return "AdminDashBoard?faces-redirect=true";
    	}
    
    
    
   
    

    private boolean searchPerformed = false; // initially false

    public boolean isSearchPerformed() {
        return searchPerformed;
    }

    public void setSearchPerformed(boolean searchPerformed) {
        this.searchPerformed = searchPerformed;
    }

    
    //-------reset page-------- 
    public String resetSearch() {
    	isSearchContext = true;
    	System.out.println("=== RESETTING SEARCH ===");
        System.out.println("Current values before reset - Type: " + searchType + 
                          ", Value: " + searchValue + 
                          ", Mode: " + nameSearchMode);
        
        this.searchType = null;
        this.searchValue = null;
        this.nameSearchMode = null;
        this.recipient = null;
        this.recipientList = null;
        this.resultList = null;
        this.currentPage = 0;
        this.sortColumn = null;
        this.sortAscending = true;
        this.searchPerformed = false;
        
        this.searchResultList = new ArrayList<>();
        this.searchCurrentPageIndex = 0;
        
     // to Force a full refresh of the view
        FacesContext.getCurrentInstance().getPartialViewContext().getRenderIds()
            .add("tableForm"); // Update the entire table form
        
        System.out.println("Values after reset - Type: " + searchType + 
                ", Value: " + searchValue + 
                ", Mode: " + nameSearchMode);
        return null;
    }
    
    
    
 // Add this field to track sorting for lastModifiedAt
    private boolean lastModifiedSortAdded = false;

    // Add this method to format the last modified timestamp or show "Not updated yet"
    public String getFormattedLastModified(Date lastModified) {
        if (lastModified == null) {
            return "Not updated yet";
        }
        // Format the date as you prefer
        return new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss").format(lastModified);
    }
    
    


    
  

}

